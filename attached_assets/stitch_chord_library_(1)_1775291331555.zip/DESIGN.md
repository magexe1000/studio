# Design System: The Harmonic Minimalist

## 1. Overview & Creative North Star
**Creative North Star: "The Silent Conductor"**

This design system rejects the cluttered, utility-first aesthetic of traditional music software in favor of a high-end, editorial experience. It is designed to feel like a premium instrument—tactile, precise, and unobtrusive. By utilizing "Soft Dark" tones and intentional asymmetry, we move away from the "app" feel toward a "workspace" feel. 

The goal is to provide a UI that breathes. We break the rigid, boxy grid of standard chord apps by using generous white space (defined by our spacing scale) and overlapping tonal layers. This creates a sense of depth and focus, allowing the musician’s creativity to remain the protagonist while the interface acts as a silent, sophisticated conductor.

---

## 2. Colors & Tonal Depth
Our palette is a study in monochromatic sophistication with surgical strikes of high-contrast blue.

- **The "No-Line" Rule:** 1px solid borders are strictly prohibited for sectioning. Structural boundaries must be defined solely through background color shifts. For example, a chord library section using `surface_container_low` should sit directly on a `surface` background without a stroke.
- **Surface Hierarchy & Nesting:** Treat the UI as physical layers of matte material.
    - **Base Layer:** `surface` (#0e0e0e) for the global background.
    - **Primary Workspaces:** `surface_container` (#191a1a) for main content areas.
    - **Interactive Elements:** `surface_container_high` (#1f2020) for cards or chord tiles.
- **The "Glass & Gradient" Rule:** To achieve a "Creative Software" feel, use Glassmorphism for floating overlays (e.g., chord modifiers or menus). Apply `surface_variant` at 60% opacity with a `20px` backdrop blur. 
- **Signature Textures:** For the main "Play" or "Select" actions, use a subtle linear gradient from `tertiary` (#679cff) to `tertiary_container` (#007aff). This adds a "jewel-like" depth that distinguishes the action from the flat UI.

---

## 3. Typography
We use a dual-typeface system to balance technical precision with editorial elegance.

- **Display & Headlines (Manrope):** Chosen for its modern, geometric construction. Use `display-md` for chord names to create a bold, iconic center of gravity.
- **Labels & Technical Data (Inter):** Use `label-md` for fingering charts and fret numbers. Inter’s high x-height ensures legibility even at the small `label-sm` scale (#0.6875rem).
- **Hierarchy as Identity:** Use `on_surface_variant` (#acabaa) for secondary metadata to create a natural "recessed" look, keeping the focus on the primary chord (using `on_surface` #e7e5e4).

---

## 4. Elevation & Depth
Depth is achieved through **Tonal Layering**, not structural lines.

- **The Layering Principle:** Instead of shadows, stack containers. Place a `surface_container_lowest` chord tile inside a `surface_container_high` tray to create an "inset" look.
- **Ambient Shadows:** For floating elements (Modals/Popovers), use a shadow with a `40px` blur, `0%` spread, and `8%` opacity. The color must be a tinted version of `on_background` to feel like natural ambient occlusion.
- **The "Ghost Border" Fallback:** If accessibility requires a container edge, use a "Ghost Border": `outline_variant` (#484848) at **15% opacity**. Never use 100% opaque outlines.
- **Glassmorphism:** Use `surface_bright` (#2c2c2c) at 40% opacity for floating toolbars to allow the chord shapes underneath to bleed through softly, maintaining the user's spatial context.

---

## 5. Components

### Chord Tiles (Cards)
- **Style:** No borders. Use `surface_container_highest` for the active state.
- **Corners:** Use `xl` (1.5rem) for the outer container and `lg` (1rem) for internal chord tiles to create a nested, organic feel.
- **Spacing:** Use spacing token `4` (1.4rem) for internal padding.

### Action Buttons
- **Primary:** `tertiary` background with `on_tertiary` text. Use `full` (9999px) roundedness for a premium "pill" feel.
- **Secondary:** `primary_container` background. No border. Soft `md` (0.75rem) corners.
- **State Transition:** On press, shift background from `surface_container_high` to `surface_bright`.

### Lists & Chord Progressions
- **Forbid Dividers:** Do not use lines to separate chords in a progression. Use spacing token `3` (1rem) as a rhythmic gap.
- **Interaction:** Use a `2px` vertical accent of `tertiary` on the left side of a list item to indicate the "currently playing" chord.

### Input Fields (Tempo/Key Search)
- **Style:** Use `surface_container_low` with a `Ghost Border`. 
- **Focus State:** Transition the border to 40% opacity `tertiary`. Do not use a heavy glow; keep it surgical.

### Special Component: The Fretboard Visualizer
- **Strings:** Use `outline_variant` at 20% opacity.
- **Markers/Dots:** Use `primary` (#c6c6c7) for a high-contrast, professional look against the `surface` background.

---

## 6. Do’s and Don’ts

### Do:
- **Do** use `20` (7rem) or `24` (8.5rem) spacing for top-level margins to create an "Editorial" feel.
- **Do** use `on_surface_variant` for all non-essential UI text to reduce visual noise.
- **Do** utilize `surface_container_lowest` (#000000) for deep-well backgrounds where chord diagrams sit, making them pop.

### Don't:
- **Don't** use 100% white (#ffffff) for text. Always use `on_surface` (#e7e5e4) to avoid "retina burn" in dark environments.
- **Don't** use standard "Drop Shadows." If an element doesn't feel elevated enough through color alone, use a subtle `surface_bright` inner glow.
- **Don't** cram elements. If you feel the need for a divider line, it’s a sign you need more spacing (increment by 1.5 units on the spacing scale).